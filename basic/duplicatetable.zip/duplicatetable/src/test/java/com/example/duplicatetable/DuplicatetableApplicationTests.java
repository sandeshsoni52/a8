package com.example.duplicatetable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuplicatetableApplicationTests {

	@Test
	void contextLoads() {
	}

}
