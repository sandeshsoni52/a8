package in.ac.mgmu.seatallocation.postgresql_queries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostgresqlQueriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
